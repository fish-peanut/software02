import json
import random
import pymysql
from flask import Flask, make_response, request


# CREATE USER 'players'@'localhost' IDENTIFIED BY '123456'
# GRANT SELECT,UPDATE,INSERT ON *.* TO 'players'@localhost
# use player_list;
# CREATE TABLE player(
#     id INT(20) PRIMARY KEY AUTO_INCREMENT COMMENT'自增id',
#     player_name VARCHAR(20) NOT NULL COMMENT'玩家id',
#     score INT(3) NOT NULL COMMENT'分数'
# )ENGINE = INNODB DEFAULT CHARSET = utf8mb4;
# insert into player(id,score) values ('chicken',10);

app = Flask(__name__)
# host = '192.168.31.53'  # 数据库ipv4地址,换了wifi自动失效
host = 'localhost'


@app.route('/insert', methods=['POST', 'GET'])
def insert_data():                      # 插入玩家对战结束后结算数据
    player_name = request.args.get("player_name")
    player_name = str(player_name)
    player_score = request.args.get("player_score")
    player_score = int(player_score)
    connect = pymysql.connect(
        host=host,
        user='players',
        password='123456',
        port=3306,
        db='player_list',
        charset='utf8'
    )
    cur = connect.cursor()
    sql_sentence = f"insert into player(player_name,score) values ('{player_name}', {player_score});"
    cur.execute(sql_sentence)
    connect.commit()
    cur.close()
    connect.close()
    return None


@app.route('/get_player_list', methods=['POST', 'GET'])
def get_player_list():       # 查询排行榜以及玩家的分数排名
    player_name = request.args.get("player_name")
    player_name = str(player_name)
    connect = pymysql.connect(
        host=host,
        user='players',
        password='123456',
        port=3306,
        db='player_list',
        charset='utf8'
    )
    cur = connect.cursor()
    sql_sentence = "SELECT player_name,score FROM player ORDER BY score DESC LIMIT 0,10"
    cur.execute(sql_sentence)
    result = cur.fetchall()
    sql_sentence_me = f"select row_num,player_name,score from (SELECT row_number() over (ORDER BY score DESC) row_num,player_name,score FROM player) as p_list where player_name = '{player_name}';"
    cur.execute(sql_sentence_me)
    result_me = cur.fetchall()
    data_dir = {
        'player_name': [],
        'score': [],
        'rank_me': result_me[0][0],
        'score_me': result_me[0][2],
    }
    for i in range(len(result)):
        data_dir['player_name'].append(result[i][0])
        data_dir['score'].append(result[i][1])
    connect.commit()
    cur.close()
    connect.close()
    response = make_response(json.dumps(data_dir, ensure_ascii=False))
    # response.mimetype = 'application/json'
    return response


@app.route('/the_next_step', methods=['POST', 'GET'])
def the_next_step():        # ai的下一步走法
    ownBoard = request.args.get("ownBoard")
    otherBoard = request.args.get("otherBoard")
    figure = int(request.args.get("figure"))
    place = nextStep(ownBoard, otherBoard, figure)
    place_dir = {
        "place": place
    }
    response = make_response(json.dumps(place_dir, ensure_ascii=False))
    return response


def nextStep(ownBoard,otherBoard,figure):   # ai实现的主要函数
    next_place = -1
    count_remove = 0
    room = 0
    next_place_in = -1
    count_remove_in = 0
    room_in = 0
    for col in range(3):
        place_find = 0
        column = col * 3
        if 0 in ownBoard[column + 0:column + 3] and figure in otherBoard[column + 0:column + 3]:
            next_place_in = ownBoard[column + 0:column + 3].index(0) + column
            count_remove_in = otherBoard[column + 0:column + 3].count(figure)
            room_in = ownBoard[column + 0:column + 3].count(0)
            place_find = 1
        if place_find == 1 and (count_remove_in > count_remove or (count_remove_in == count_remove and room_in > room)):
            next_place = next_place_in
            count_remove = count_remove_in
            room = room
    if next_place == -1:
        random_list = []
        for i in range(9):
            if ownBoard[i] == 0:
                random_list.append(i)
        next_place = random.choice(random_list)
    return next_place


if __name__ == '__main__':
    app.run()
